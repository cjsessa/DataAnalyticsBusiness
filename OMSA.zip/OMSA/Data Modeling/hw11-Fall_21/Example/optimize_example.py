"""
ISYE6501 Week 11 Sample Code
Author: Patrick Kriengsiri
"""
from pulp import *
import pandas as pd

# Read in our spreadsheet
candy = pd.read_excel("candy.xls")
print( candy )

# Looks like the last few rows are junk... get rid of them
# Note the indexing!
candy = candy[:3]
print( candy )

# Let's make some lists from this data
candies = list(candy["Candy"])
prices = list(candy["Price_serving"])
sugar = list(candy["Sugar_g"])
fat = list(candy["Fat_g"])

# Create the optimization problem
prob = LpProblem('CandyProblem', LpMinimize)

# Create the variables 
# Note: this is for illustrative purposes, this is NOT the most efficient way to do this!
lpv_snickers = LpVariable(candies[0],0)
lpv_twix = LpVariable(candies[1],0)
lpv_aj = LpVariable(candies[2],0)

# Add the constraints. First comes the objective function
# Note: this is for illustrative purposes, this is NOT the most efficient way to do this!
prob += prices[0]*lpv_snickers + prices[1]*lpv_twix + prices[2]*lpv_aj

# Minimum sugar intake - 25g, don't really care about too much sugar
# Note: this is for illustrative purposes, this is NOT the most efficient way to do this!
prob += sugar[0]*lpv_snickers + sugar[1]*lpv_twix + sugar[2]*lpv_aj >= 25

# Maximum fat intake - 20g
# Note: this is for illustrative purposes, this is NOT the most efficient way to do this!
prob += fat[0]*lpv_snickers + fat[1]*lpv_twix + fat[2]*lpv_aj <= 20

# Solve and check out the results
soln = prob.solve()

print( LpStatus[prob.status])
for v in prob.variables():
    print( f"{v.name} = {v.varValue:.2f}")

print(f"Cost: {value(prob.objective)}")

###

# Redo this as an integer problem
prob = LpProblem('CandyProblem_integer', LpMinimize)

# New Variables
lpv_snickers = LpVariable(candies[0],0,None,LpInteger)
lpv_twix = LpVariable(candies[1],0,None,LpInteger)
lpv_aj = LpVariable(candies[2],0,None,LpInteger)

# Everything else is the same
prob += prices[0]*lpv_snickers + prices[1]*lpv_twix + prices[2]*lpv_aj
prob += sugar[0]*lpv_snickers + sugar[1]*lpv_twix + sugar[2]*lpv_aj >= 25
prob += fat[0]*lpv_snickers + fat[1]*lpv_twix + fat[2]*lpv_aj <= 20

# Solve and check out the results
soln = prob.solve()

print( LpStatus[prob.status])
for v in prob.variables():
    print( f"{v.name} = {v.varValue:.2f}")

print(f"Cost: {value(prob.objective)}")