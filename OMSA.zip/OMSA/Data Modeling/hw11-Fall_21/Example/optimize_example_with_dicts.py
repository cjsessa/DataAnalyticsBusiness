"""
ISYE6501 Week 11 Sample Code (using dictionaries)
Author: Patrick Kriengsiri
"""
from pulp import *
import pandas as pd

# Read in our spreadsheet
candy = pd.read_excel("candy.xls")
candy = candy[:3]

# Get a nested list from the values 
# This is a list where each item is a row, as a list
candy_data = candy.values.tolist()
print(candy_data)

# Make a list of candies
candies = [x[0] for x in candy_data]

# Make dictionaries (key / value pairs) from the lists
# Key = candy name
# Value = value
costs = {x[0]:x[1] for x in candy_data}
sugars = {x[0]:x[3] for x in candy_data}
fats = {x[0]:x[4] for x in candy_data}

# Create the optimization problem
prob = LpProblem('CandyProblem', LpMinimize)

# Create the variables ising LpVariable.dicts
lp_vars = LpVariable.dicts( "Amounts", candies, 0 )

# Create objective function / constraints using lpSum and list comprehension
# Note that you're iterative over items in the candies list and using that as 
# a key into the appropriate dictionaries
prob += lpSum( costs[i] * lp_vars[i] for i in candies )         # objective function
prob += lpSum( sugars[i] * lp_vars[i] for i in candies ) >= 25  # min 25g sugar
prob += lpSum( fats[i] * lp_vars[i] for i in candies )   <= 20  # max 20g fat

# Solve and check out the results
soln = prob.solve()

print( LpStatus[prob.status])
for v in prob.variables():
    print( f"{v.name} = {v.varValue:.2f}")

print(f"Cost: {value(prob.objective)}")