install.packages("ClusterR")
install.packages("cluster")
install.packages("factoextra")


################################################################
####                 Importing Libraries                    ####
################################################################

library(ggplot2)
library(tidyverse)
library(dplyr)
library(ClusterR)
library(cluster)
library(factoextra)



################################################################
####        Preparing directories & importing data          ####
################################################################

#setting working directory to Data Modeling folder & confirming it processed
setwd("C:/Users/adfil/Desktop/OMSA/Data Modeling")
getwd()

#clearing any previous data
rm(list=ls())


#reading in the txt file with columns headers using a relative path
df<- read.table("hw2-Fall_21/data 4.2/iris.txt", header= TRUE)


#confirming data read in properly

#Sepal.Length Sepal.Width Petal.Length Petal.Width Species
#1          5.1         3.5          1.4         0.2  setosa
#2          4.9         3.0          1.4         0.2  setosa
#3          4.7         3.2          1.3         0.2  setosa
#4          4.6         3.1          1.5         0.2  setosa
#5          5.0         3.6          1.4         0.2  setosa
#6          5.4         3.9          1.7         0.4  setosa

#scaling data to account for different sizes
df.scaled <- scale(df[,-5])

#Viewing Scaled data
head(df.scaled)


#Sepal.Length Sepal.Width Petal.Length Petal.Width
#1   -0.8976739  1.01560199    -1.335752   -1.311052
#2   -1.1392005 -0.13153881    -1.335752   -1.311052
#3   -1.3807271  0.32731751    -1.392399   -1.311052
#4   -1.5014904  0.09788935    -1.279104   -1.311052
#5   -1.0184372  1.24503015    -1.335752   -1.311052
#6   -0.5353840  1.93331463    -1.165809   -1.048667



#setting seed for reproducibility
set.seed(123)


################################################################
####                    Visualizing Data                    ####
################################################################

#Note, as demonstrated in office hours notes:

ggplot(df, aes(Sepal.Length, Sepal.Width, color = Species)) + geom_point()
ggplot(df, aes(Petal.Length, Petal.Width, color = Species)) + geom_point()

#we see that looking at petal dimensions leads to more clear cut cluster distinctions

km.res <- kmeans(df.scaled[,1:4],centers=2, nstart=25)
print(km.res)


fviz_cluster(km.res, df[,-5], ellipse.type = "norm", geom = "point")





cluster_assignments <- cbind(df, cluster = km.res$cluster)
cluster_assignments

km.res$cluster

head(km.res$cluster, 4)

km.res$size
km.res$centers