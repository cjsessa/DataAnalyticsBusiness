################################################################
####      Installing Necessary Packages for Vanilladot      ####
####    Note: commenting out as only needed first time      ####
################################################################

  
  #install.packages("kernlab")
  #install.packages("kknn")
  #install.packages("ggplot2")
  #install.packages("tidyverse")
################################################################
####           Importing Libraries for Vanilladot           ####
################################################################

  library(kernlab)
  library(kknn)
  library(ggplot2)
  library(tidyverse)

################################################################
####        Preparing directories & importing data          ####
################################################################

  #setting working directory to Data Modeling folder & confirming it processed
  setwd("C:/Users/adfil/Desktop/OMSA/Data Modeling")
  getwd()
  
  
  #reading in the txt file with columns headers using a relative path
  df<- read.table("hw1-Fall_21/data 2.2/credit_card_data-headers.txt", header= TRUE)
  #confirming data read in properly
  head(df)

################################################################
####        Preparing data to be used in Vanilladot         ####
################################################################

  #converting data into matrix format to work for vanilladot
  data <- data.matrix(df)
  
  head(data)

################################################################
####     1) Using sample code provided in Homework          ####
################################################################

  # call ksvm.  Vanilladot is a simple linear kernel.
  model <- ksvm(data[,1:10],data[,11],type="C-svc",kernel="vanilladot",C=100,scaled=TRUE)
  
  # calculate a1.am
  a <- colSums(model@xmatrix[[1]] * model@coef[[1]])
  a
  # calculate a0
  a0 <- model@b
  a0
  # see what the model predicts
  pred <- predict(model,data[,1:10])
  pred
  # see what fraction of the model's predictions match the actual classification
  sum(pred == data[,11]) / nrow(data)

  
#notes, coefficients a1...am 
  
 # A1            A2            A3            A8            A9           A10           A11           A12           A14           A15 
 # -0.0010065348 -0.0011729048 -0.0016261967  0.0030064203  1.0049405641 -0.0028259432  0.0002600295 -0.0005349551 -0.0012283758  0.1063633995
  
# A0
  #-0.08158492
  
#prediction accuracy

  #0.8639144
  
################################################################
####           Creating loop of various C values            ####
################################################################

Prediction_vector = c(0,100)
  
  
  for(i in (1:100)){
    model <- ksvm(data[,1:10],data[,11],type="C-svc",kernel="vanilladot",C=10^i,scaled=TRUE)
    # calculate a1.am
    a <- colSums(model@xmatrix[[1]] * model@coef[[1]])
    a
    # calculate a0
    a0 <- model@b
    a0
    # see what the model predicts
    pred <- predict(model,data[,1:10])
    pred
    # see what fraction of the model's predictions match the actual classification
    Prediction_vector[i] <- c(sum(pred == data[,11]) / nrow(data))
    print(Prediction_vector[i])
      if(Prediction_vector[i]>.87){
        print(Prediction_vector[i])
        print(i)
      }
  }

  Prediction_vector
#Notes, uses various values of C, prediction value decreased as C became larger than 100
#no improvements by the starting point of 100, will keep as is
  
  
################################################################
####      1.B) Rerun removing low impact variables          ####
################################################################
  
  #removing low impact variables
  df1 <- subset(df, select = -c(A1,A2,A11,A12))
  
  datar <- data.matrix(df1)
  datar
  
  #rerunning model with C value of 100 & reduced variable set
  
  model <- ksvm(datar[,1:6],datar[,7],type="C-svc",kernel="vanilladot",C=100,scaled=TRUE)
  
  # calculate a1.am
  a <- colSums(model@xmatrix[[1]] * model@coef[[1]])
  a
  # calculate a0
  a0 <- model@b
  a0
  # see what the model predicts
  pred <- predict(model,datar[,1:6])
  pred
  # see what fraction of the model's predictions match the actual classification
  sum(pred == datar[,7]) / nrow(datar)
  
  #prediction accuracy .864
  
  
  #rerunning model trying different values of C
  
  Prediction_vector = c(0,100)
  
  
  for(i in (1:100)){

    
    model <- ksvm(datar[,1:6],datar[,7],type="C-svc",kernel="vanilladot",C=i,scaled=TRUE)
    # calculate a1.am
    a <- colSums(model@xmatrix[[1]] * model@coef[[1]])
    a
    # calculate a0
    a0 <- model@b
    a0
    # see what the model predicts
    pred <- predict(model,datar[,1:6])
    pred
    # see what fraction of the model's predictions match the actual classification
    Prediction_vector[i] <- sum(pred == datar[,7]) / nrow(datar)
    
    
    # see what fraction of the model's predictions match the actual classification
    if(Prediction_vector[i]>.87){
      print(Prediction_vector[i])
      print(i)
    }
  }
  
  #notes, different values of C & reducing variables did not change prediction power


################################################################
####       3) Use kknn model to classify dataset            ####
################################################################


#creating an empty vector for predicted values, calculated accuracy, and index
pred_kknn <- c()
accuracy <-c()
index <- c()


#creating a loop to try different values of k (1 to 100)


for (j in (1:100)){

  #creating a loop to go through every row of the data
    for (i in 1:nrow(df)){
      
      #use df[-i] trick found in homework to ensure we do not include the observation as one of the 
      #nearest neighbors
      
      kknn_model =kknn(R1~.,df[-i,],df[i,],k=j, scale = TRUE)
      
      #round predicted value to 0 or 1
      
      pred_kknn[i] <- as.integer(fitted(kknn_model)+0.5)
     
    }

  #creating predicted percentage by K value
  a <- sum(pred_kknn == df[,11]) / nrow(df)
  k <- j
  
  #creating vectors of both accuracy percentage & index
  accuracy <-c(accuracy,a)
  index <- c(index,k)
  
}

################################################################
####       3) Visualize Results of KKNN Model               ####
################################################################


#turning vectors of calculated data into a data frame
kknn_accuracy_table <- data.frame(index,accuracy)

#finding max value of accuracy
#occurs at K = 12,15 with a accuracy value of .8532
kknn_accuracy_table %>% slice_max(accuracy)

#creating scatter plot using ggplot
ggplot(data=kknn_accuracy_table, aes(x=index, y=accuracy)) +
  geom_point() + xlim(0,100) + ylim(.8,1) + ggtitle("Accuracy of Model as K increases")

################################################################
####      3.B) Use kknn model to classify dataset           ####
####              Using reduced variable set                ####
################################################################

#redoing 3 with reduced variables

#creating an empty vector for predicted values, calculated accuracy, and index
pred_kknn1 <- c()
accuracy1 <-c()
index1 <- c()


for (j in (1:100)){
  
  #creating a loop to go through every row of the data
  for (i in 1:nrow(df1)){
    
    #use df[-i] trick found in homework to ensure we do not include the observation as one of the 
    #nearest neighbors
    
    kknn_model1 =kknn(R1~.,df1[-i,],df1[i,],k=j, scale = TRUE)
    
    #round predicted value to 0 or 1
    
    pred_kknn[i] <- as.integer(fitted(kknn_model)+0.5)
    
  }
  
  #creating predicted percentage by K value
  a <- sum(pred_kknn == df1[,7]) / nrow(df1)
  k <- j
  
  #creating vectors of both accuracy percentage & index
  accuracy1 <-c(accuracy,a)
  index1 <- c(index,k)
  
}


################################################################
####       3.B) Visualize Results of KKNN Model               ####
################################################################


#turning vectors of calculated data into a data frame
kknn_accuracy_table <- data.frame(index1,accuracy1)

kknn_accuracy_table %>% slice_max(accuracy1)

#creating scatter plot using ggplot
ggplot(data=kknn_accuracy_table, aes(x=index1, y=accuracy1)) +
  geom_point() + xlim(0,100) + ylim(.8,1) + ggtitle("Accuracy of Model as K increases (Reduced Variables)")

