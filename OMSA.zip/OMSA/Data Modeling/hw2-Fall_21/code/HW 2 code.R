################################################################
####      Installing Necessary Packages for Vanilladot      ####
####    Note: commenting out as only needed first time      ####
################################################################


#install.packages("kernlab")
#install.packages("kknn")
#install.packages("ggplot2")
#install.packages("tidyverse")
################################################################
####           Importing Libraries for Vanilladot           ####
################################################################

library(kernlab)
library(kknn)
library(ggplot2)
library(tidyverse)

################################################################
####        Preparing directories & importing data          ####
################################################################

#setting working directory to Data Modeling folder & confirming it processed
setwd("C:/Users/adfil/Desktop/OMSA/Data Modeling")
getwd()

#clearing any previous data
rm(list=ls())

#reading in the txt file with columns headers using a relative path
df<- read.table("hw2-Fall_21/data 3.1/credit_card_data-headers.txt", header= TRUE)
#confirming data read in properly
head(df)

################################################################
####           Splitting into Test/Train Data               ####
################################################################



#setting seed while working on code
set.seed(123)

#randomly sorting entire dataframe
df_shuffle <- df[sample(1:nrow(df)),]

#splitting data into 20% data for testing, & 80% of data for training & validation
#creating variable for amount for training & testing

train <- round(nrow(df_shuffle)*.8)
test <- round(nrow(df_shuffle)*.2)

train_df <- df[0:train,]
test_df <- df[0:test,]


################################################################
####       Using KSVM Model to do Cross Validation          ####
################################################################

#creating a vector of C values & an empty vector to deposit 
#accuracy levels into, initially tried 10^(-10:10), these accuracy
#values were much less than C = 100, used a smaller range to get
#better accuracy level

c_vector = c(.5,1,10,50,100,1000)

accuracy <-rep(0,6)



#creating a loop to try different values of C (-10:10)

for (i in (1:6)){

#create KSVM model using TRAINING data
ksvm_model = ksvm(
          as.matrix(train_df[,1:10]),
          as.factor(train_df[,11]), 
          type = "C-svc",
          kernel = "vanilladot",
          C = c_vector[i],
          scaled=TRUE) 


# see what the model predicts
  Prediction_vector <- predict(ksvm_model,test_df[,1:10])
  accuracy[i] <- sum(Prediction_vector == test_df$R1)/nrow(test_df)*100
 

}






#Sum the total of predictions over the total of actuals to get accuracy`
accuracy <- (sum(pred == test_df$R1) / nrow(test_df))*100
accuracy
accuracy

Prediction_vector
predicted[i] <- predict(ksvm_model,test_df[,1:10]) # round off to 0 or 1
}
  




##                      Model prediction                             ##
#######################################################################
#from R documentation:
#### S4 method for ksvm
#### predict(object, newdata, type = "response", coupler = "minpair")
#### here we only need object (ksvm_model) & newdata(i.e. testing data)
#######################################################################

pred = predict(ksvm_model,test_df[,1:10])

#Sum the total of predictions over the total of actuals to get accuracy`
accuracy <- (sum(pred == test_df$R1) / nrow(test_df))*100
accuracy



################################################################
####       Using train.kknn to do Cross Validation          ####
################################################################

#creating an empty vector for predicted values, calculated accuracy, and index
pred_kknn <- c()
accuracy <-c()
index <- c()


#creating a loop to try different values of k (1 to 100)


for (j in (1:2)){
  
  #creating a loop to go through every row of the data
  for (i in 1:nrow(df)){
    
    #use df[-i] trick found in homework to ensure we do not include the observation as one of the 
    #nearest neighbors
    
    kknn_model <- train.kknn(
                        R1~.,
                        train_df[-i,],
                        train_df[i,],
                        kmax = 50, 
                        scale = TRUE)
    
    
    kknn_model<- train.kknn(
      R1~.,
      data = train_df,
 
      kmax = 50, 
      scale = TRUE)
     
     pred_kknn <- as.integer(predict(kknn_model, test_df)+.5)
     pred_kknn
     a <- sum(pred_kknn == train_df[,11]) / nrow(train_df)
     a
     
     a <- sum(pred_kknn == train_df[,11]) / nrow(train_df)
     a
    
    #round predicted value to 0 or 1
    
   # pred_kknn[i] <- as.integer(fitted(kknn_model)+0.5)
    
  }
  kknn_model
}
  
  #creating predicted percentage by K value
  a <- sum(pred_kknn == df[,11]) / nrow(df)
  k <- j
  
  #creating vectors of both accuracy percentage & index
  accuracy <-c(accuracy,a)
  index <- c(index,k)
  
}




n <- 4
nr <- nrow(train_df)
for (i in (0:4)){
   
    train_df[i]<-split(train_df, rep(1:ceiling(nr/n), each=n, length.out=nr))
}

#converting data into matrix format to work for vanilladot
train_matrix <- data.matrix(train_df)
test_matrix <- data.matrix(test_df)





################################################################
####                      references                        ####
################################################################
#splitting data
## https://www.tutorialspoint.com/how-to-split-a-data-frame-in-r-into-multiple-parts-randomly

#shuffling data
## https://statisticsglobe.com/randomly-reorder-data-frame-by-row-and-column-in-r

#splitting data into equal parts
## https://stackoverflow.com/questions/37145863/splitting-a-data-frame-into-equal-parts


