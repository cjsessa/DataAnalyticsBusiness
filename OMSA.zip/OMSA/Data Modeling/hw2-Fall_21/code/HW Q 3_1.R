################################################################
####      Installing Necessary Packages for Vanilladot      ####
####    Note: commenting out as only needed first time      ####
################################################################


#install.packages("kernlab")
#install.packages("kknn")
#install.packages("ggplot2")
#install.packages("tidyverse")
################################################################
####           Importing Libraries for Vanilladot           ####
################################################################

library(kernlab)
library(kknn)
library(ggplot2)
library(tidyverse)
library(dplyr)

################################################################
####        Preparing directories & importing data          ####
################################################################

#setting working directory to Data Modeling folder & confirming it processed
setwd("C:/Users/adfil/Desktop/OMSA/Data Modeling")
getwd()

#clearing any previous data
rm(list=ls())

#reading in the txt file with columns headers using a relative path
df<- read.table("hw2-Fall_21/data 3.1/credit_card_data-headers.txt", header= TRUE)
#confirming data read in properly
head(df)



################################################################
####                  Data Prep Work
####      Splitting into Test/Train/Validate Data           ####
################################################################

#setting seed while working on code
set.seed(123)

#randomly sorting entire dataframe
  df_shuffle <- df[sample(1:nrow(df)),]

#splitting data into 20% data for testing, & 80% of data for training & validation


#creating variable for number of rows for training & testing
  
  train_validate_n <- floor(nrow(df_shuffle)*.8)
  test_n <- (floor(nrow(df_shuffle)*.2))
  train_n  <- floor(train_validate_n*.5)

#creating random sample of indicies to be used in train/validate df
  train_validate_sample <-sample(seq_len(nrow(df_shuffle)),size = train_validate_n)
  
#filtering out the train/validate subset from the shuffled df
  train_validate_df <- df_shuffle[0:train_validate_n,]
  
#creating random sample of indicies for training from the training & valiation data
  train_sample <-sample(seq_len(nrow(train_validate_df)),size = train_n)

#filtering out number of rows for training
  train_df <- train_validate_df[train_sample,]

#filtering the leftovers for the train/validate df for the validate
  validate_df <- train_validate_df[-train_sample,]

#filtering the leftovers of the train_validate df for the test
  test_df <- df_shuffle[-train_validate_sample,]



################################################################
####     (a)	using cross-validation (do this for the       ####
####     k-nearest-neighbors model; SVM is optional);       ####
################################################################

#use train.kknn model, package will use a LOOCV method for k-nearest
#neighbors up to 100 nearest neighbors, model is set to scale
#model stores the prediction values in a list format inside the model$fitted.values[[]]
#will use a loop to create prediction percentages for each value of k
    
  a <- c()
  k <- c()
  
  kknn_model =train.kknn(R1~.,df,kmax = 100, scale = TRUE)

    #creating a loop to go through every k value uesed of the data
    for (i in 1:100){
    #round predicted value to 0 or 1
    pred_kknn <-  as.integer(kknn_model$fitted.values[[i]]+.5)
    
    #creating predicted percentage by K value
    a[i] <- sum(pred_kknn == df[,11]) / nrow(df)
    k[i] <- i
    
  }
  
 
  #turning vectors of calculated data into a data frame
  kknn_accuracy_table <- data.frame(k,a)
  
  #finding max value of accuracy
  #occurs at K = 12, 15, 16, & 17 with a accuracy value of .853
  kknn_accuracy_table %>% slice_max(a)
  
  #creating scatter plot using ggplot
  ggplot(data=kknn_accuracy_table, aes(x=k, y=a)) +
    geom_point() + xlim(0,100) + ylim(0,1) + ggtitle("Accuracy of Model as K increases")
    


################################################################
####     (b)split data into training, validation, & test    ####
####        data sets & use KNN or SVM                      ####
################################################################

##note, data was split as prepwork in the beginning
##Model prediction Notes:


c_vector <- c(.5,1,10,50,100,1000)
ksvm_accuracy <-rep(0,6)
  
  
  for (i in (1:6)){
    
    #create KSVM model using TRAINING & VALIDATION data
    ksvm_model = ksvm(
      as.matrix(train_df[,1:10]),
      as.factor(train_df[,11]), 
      type = "C-svc",
      kernel = "vanilladot",
      C = 10^c_vector[i],
      scaled=TRUE) 
    
    # see what the model predicts
    Prediction_vector <- predict(ksvm_model,validate_df[,1:10])
    ksvm_accuracy[i] <- sum(Prediction_vector == validate_df$R1)/nrow(validate_df)
    
  }
  print(ksvm_accuracy)
  
  #> print(ksvm_accuracy)
  #[1] 0.8740458 0.8740458 0.7328244 0.7328244 0.7328244 0.7328244
  #best model is when C = 10^.5 or 10^1
  
  #Redo KSVM model using all of TRAINING & VALIDATION data against TEST ata
  ksvm_model = ksvm(
    as.matrix(train_validate_df[,1:10]),
    as.factor(train_validate_df[,11]), 
    type = "C-svc",
    kernel = "vanilladot",
    C = 10^.5,
    scaled=TRUE) 
  
  # see what the model predicts
  Prediction_vector <- predict(ksvm_model,test_df[,1:10])
  ksvm_accuracy <- sum(Prediction_vector == test_df$R1)/nrow(test_df)
  
  
  print(ksvm_accuracy)
  
  #> print(ksvm_accuracy)
  #[1] 0.8625954
  



################################################################
####                      references                        ####
################################################################
#splitting data
## https://www.tutorialspoint.com/how-to-split-a-data-frame-in-r-into-multiple-parts-randomly

#shuffling data
## https://statisticsglobe.com/randomly-reorder-data-frame-by-row-and-column-in-r

#splitting data into equal parts
## https://stackoverflow.com/questions/37145863/splitting-a-data-frame-into-equal-parts


