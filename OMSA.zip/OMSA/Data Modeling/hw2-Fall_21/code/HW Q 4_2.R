################################################################
####           Importing Libraries for Vanilladot           ####
################################################################

library(ggplot2)
library(tidyverse)
library(factoextra)

################################################################
####        Preparing directories & importing data          ####
################################################################

#setting working directory to Data Modeling folder & confirming it processed
setwd("C:/Users/adfil/Desktop/OMSA/Data Modeling")
getwd()

#clearing any previous data
rm(list=ls())

#reading in the txt file with columns headers using a relative path
df<- read.table("hw2-Fall_21/data 4.2/iris.txt", header= TRUE)

#setting seed for reproducibility:
set.seed(123)



################################################################
####                   Reviewing Data                       ####
################################################################

#confirming data read in properly
head(df)

    
    #Sepal.Length Sepal.Width Petal.Length Petal.Width Species
    #1          5.1         3.5          1.4         0.2  setosa
    #2          4.9         3.0          1.4         0.2  setosa
    #3          4.7         3.2          1.3         0.2  setosa
    #4          4.6         3.1          1.5         0.2  setosa
    #5          5.0         3.6          1.4         0.2  setosa
    #6          5.4         3.9          1.7         0.4  setosa

#looking at outcome variables, 50 of 3 different types
table(df$Species)

  #  setosa versicolor  virginica 
  #50         50         50 

#visualizing the actual categories
ggplot(df, aes(Sepal.Length, Sepal.Width, color = Species)) + geom_point()

ggplot(df, aes(Petal.Length, Petal.Width, color = Species)) + geom_point()


#removing the response variable (i.e. column 5) & scaling data
df.scaled <- scale(df[,-5])

##############################################################
# Finding Optimal number of Clusters using Elbow Graph Method#
##############################################################

#notes, sapply function takes a list, vector or DF as an input
#and gives output in vector or matrix
#we want the function created to have output in matrix form so
#we are able to graph it with a plot function

#function runs through 1-15 clusters, resampling the data 50 times
#so each data point is closest to only 1 cluster center

#tot.withinss is the total within-cluster sum of squares

k.max <-15   #setting maximum number of k clusters

wss <- sapply(1:k.max,
              function(k){
                kmeans(
                  df.scaled,
                  k,
                  nstart = 1000,
                  iter.max = 15)$tot.withinss
              }
)

plot(1:k.max, wss,
  type="b", pch = 19, frame = FALSE,
  xlab = "Number of clusters K",
  ylab = "Total within-clusters sum of squares")

              
##############################################################
#      Rerunning kmeans with optimal number of clusters      #
##############################################################

km.res <- kmeans(df.scaled, 3, nstart = 1000)


##############################################################
#        Visualizing kmeans clusters using fviz_cluster      #
##############################################################

fviz_cluster(km.res, df[,-5],ellipse.type="norm", geom = "point")













################################################################
####                      references                        ####
################################################################

#plotting elbow graph
#r-bloggers.com/2017/02/finding-optimal-number-of-clusters/

#sapply function
#guru99.com/r-apply-sapply-tapply.html

#tot-withiness explanation
#stats.stackexchange.com/questions/176751/how-can-i-interpret-the-results-of-r-kmeans-function

#fviz_cluster 
#rpkgs.datanovia.com/factoextra/reference/fviz_cluster.html

#kmeans examples
#datanovia.com/en/lessons/k-means-clustering-in-r-algorith-and-practical-examples
