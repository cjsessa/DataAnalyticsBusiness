#Seungsoo Hong
#ISYE6501 Question 5.1
#HW 3

rm(list = ls())
library(knitr)
library(corrplot)
library(outliers)

uscrime <- read.table("uscrime.txt", stringsAsFactors = FALSE, header = TRUE)
head(uscrime)
crime <- uscrime[,"Crime"]

plot(crime)
plot(uscrime[,16], type = "b")
plot(uscrime$Pop,crime)

# Reading the data

# Check for normality of the crime data since it's an assumption of the Grubbs test.
# Null hypothesis: Data is normally distributed 

shapiro.test(crime)
## 	Shapiro normality test
## data:  crime
## W = 0.91273, p-value = 0.001882

# low p-value rejects the null hypothesis that the data is normally distributed
# Normality tests can give skewed answers since they focus too much on few data 
# points. Low p may be an indicator for outliers.

# Look at the Q-Q plot of the crime data as another method to test the normality of the data
qqnorm(crime)
# Q-Q plot suggests that the "middle" of the data is normally distributed, so we may assume
# that the data is approximately normally distributed and run the Grubbs' test

hist(crime)
g = uscrime[,16]
m<-mean(g)
std<-sqrt(var(g))
hist(uscrime[,16], density=10, breaks=12, prob=T, xlab="x-var", main="normal curve over histogram")
curve(dnorm(x, mean=m, sd=std),
      col ="darkblue", lwd=2, add=T, yaxt="n")

# Run the Grubbs' test for two outliers on opposite tails
# Null hypothesis: Both min AND max cannot be outliers, but one could be
grubbs.test(crime, type = 11)

## data:  crime
## G = 4.26880, U = 0.78103, p-value = 1
## alternative hypothesis: 342 and 1993 are outliers
# p-value = 1, at least one of the extremes (highest or lowest)
# is NOT an outlier.

#Null Hypothesis: no outliers for either tails
grubbs.test(crime, type = 10)
grubbs.test(crime, type = 10, opposite = T)

## data:  crime
## G = 2.8129, U = 0.8243, p-value = 0.07887
## alternative hypothesis: highest value 1993 is an outlier
boxplot(crime)
# Depending on the threshold value of p, this could be questioned whether or not
# it is an outlier. However, when looking at a boxplot, it clearly shows the 
# point 1993 as an outlier.

# Take point 1993 out to see if there would be other outliers.
crime2 <-uscrime[-26,16]
plot(crime2)
hist(crime2)
qqnorm(crime2)

# 1993 is now out, but shows 1969 as the outlier with a much lower p value!
# This may show another potential outlier, but the drawback would be the 
# potential of classifying NEW outliers as we are taking out points out of
# a limited data set, the mean would differ with each point taken out.