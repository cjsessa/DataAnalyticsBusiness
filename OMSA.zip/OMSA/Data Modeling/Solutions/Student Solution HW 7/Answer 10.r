########### 10.1a - Regression Tree

rm(list = ls())
library(tree)

#Read file into a dataframe
uscrime <- read.table("C:\\Users\\Azhar Saiyed\\Desktop\\Analytics\\Micro Masters\\ISYE6501 - Introduction to Analytics Modeling\\Homework\\hw7-Fall_21\\data 10.1\\uscrime.txt", sep="\t", stringsAsFactors = FALSE, header=TRUE)

#Confirm the data read
head(uscrime)

#   M     So Ed   Po1  Po2    LF   M.F Pop   NW    U1  U2 Wealth Ineq     Prob    Time Crime
# 1 15.1  1  9.1  5.8  5.6 0.510  95.0  33 30.1 0.108 4.1   3940 26.1 0.084602 26.2011   791
# 2 14.3  0 11.3 10.3  9.5 0.583 101.2  13 10.2 0.096 3.6   5570 19.4 0.029599 25.2999  1635
# 3 14.2  1  8.9  4.5  4.4 0.533  96.9  18 21.9 0.094 3.3   3180 25.0 0.083401 24.3006   578
# 4 13.6  0 12.1 14.9 14.1 0.577  99.4 157  8.0 0.102 3.9   6730 16.7 0.015801 29.9012  1969
# 5 14.1  0 12.1 10.9 10.1 0.591  98.5  18  3.0 0.091 2.0   5780 17.4 0.041399 21.2998  1234
# 6 12.1  0 11.0 11.8 11.5 0.547  96.4  25  4.4 0.084 2.9   6890 12.6 0.034201 20.9995   682

#Fit the data above against Regression Tree
uscrimetree <- tree(Crime~., data = uscrime)
summary(uscrimetree)

# Regression tree:
#  tree(formula = Crime ~ ., data = dfuscrime)
# Variables actually used in tree construction:
#  [1] "Po1" "Pop" "LF"  "NW" 
# Number of terminal nodes:  7 
# Residual mean deviance:  47390 = 1896000 / 40 
# Distribution of residuals:
#  Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
#-573.900  -98.300   -1.545    0.000  110.600  490.100 


# 4 predictors 
# 7 leaf nodes
# 47390 mean deviance

# Visualize the tree
plot(uscrimetree)
text(uscrimetree)

uscrimetree$frame
# var  n        dev      yval splits.cutleft splits.cutright
# 1     Po1 47 6880927.66  905.0851          <7.65           >7.65
# 2     Pop 23  779243.48  669.6087          <22.5           >22.5
# 4      LF 12  243811.00  550.5000        <0.5675         >0.5675
# 8  <leaf>  7   48518.86  466.8571
# 9  <leaf>  5   77757.20  667.6000
# 5  <leaf> 11  179470.73  799.5455
# 3      NW 24 3604162.50 1130.7500          <7.65           >7.65
# 6     Pop 10  557574.90  886.9000          <21.5           >21.5
# 12 <leaf>  5  146390.80 1049.2000
# 13 <leaf>  5  147771.20  724.6000
# 7     Po1 14 2027224.93 1304.9286          <9.65           >9.65
# 14 <leaf>  6  170828.00 1041.0000
# 15 <leaf>  8 1124984.88 1502.8750

# Shows 7 leaf nodes together with the deviances (dev) and their average response (yval)
# Notice, the value of deviance is smallest at the nodes, which is exptected

uscrimetree$where
# 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 
# 6 13  4 13  9 10 12 13  6  5 13  6  6  5  6 12  4 13 10 13  6  4 12  9  5 
# 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 
# 13  4 12 13  6  4 12  6  9 10  9  6  5  6 12  5  4  6 10  4 10  9 

# Shows the node the datapoint exists under. 
# Rows 1 and 3 represent the datapoints
# Rows 2 and 4 represent the leaf node
# For example the the last data point 47 belongs to row 9 (from frame output), which predicts
# an average value of 1049.2

pred_uscrime <- predict(uscrimetree)
head(pred_uscrime)

# 1         2         3         4         5         6 
# 799.5455 1502.8750  466.8571 1502.8750 1049.2000  724.6000 

# One can see from above that the response for data point 2 and 4 for example 
# is exactly the same, both of them fall under the same row 13 (from the frame output)
# which has an average value of 1502.8750

prune.tree(uscrimetree)
# size: 7 6 5 4 3 2 1
# dev:  1895722 2013257 2276670 2632631 3364043 4383406 6880928

set.seed(99)
cv.tree(uscrimetree)
# size: 7 6 5 4 3 2 1
# dev:  7494151 7494151 7552979 7590028 8083578 7155955 7268927


# Takeaways
# This does not seem to be a good model for crime prediction as it creates 7 buckets, basically
# creates 7 zones with 7 disctinct average crime rates.
# Secondly, When cross validating, the deviance seems to increase considerably
# Pruning, does not seem to be a good idea as it'll further generalize the crime rates by reducing 
# the number of nodes.


########### 10.1b - Random Forest

rm(list = ls())
library(randomForest)

uscrime <- read.table("C:\\Users\\Azhar Saiyed\\Desktop\\Analytics\\Micro Masters\\ISYE6501 - Introduction to Analytics Modeling\\Homework\\hw7-Fall_21\\data 10.1\\uscrime.txt", sep="\t", stringsAsFactors = FALSE, header=TRUE)


set.seed(99)
num_pred <- 5
uscrimerf <- randomForest(Crime~.,
                        data = uscrime,
                        mtry = num_pred, #Number of variables randomly sampled as candidates at each split
                        importance = TRUE, #tells us which predictors are important
                        ntree = 500)


uscrimerf

# randomForest(formula = Crime ~ ., data = uscrime, mtry = num_pred,      importance = TRUE, ntree = 500) 
# Type of random forest: regression
# Number of trees: 500
# No. of variables tried at each split: 5
# 
# Mean of squared residuals: 88342.56
# % Var explained: 39.66


importance(uscrimerf)

#         %IncMSE       IncNodePurity
# M       2.8726852     203438.09
# So      2.9457139      28237.58
# Ed      3.8304083     198812.13
# Po1    11.3152247    1165693.67
# Po2    11.4339678    1184116.52
# LF      0.9846704     272682.74
# M.F     3.0173674     298943.67
# Pop     1.4809305     353139.41
# NW      8.9766221     527013.24
# U1     -1.3807865     144049.39
# U2      1.9847992     165834.48
# Wealth  3.3748048     686559.66
# Ineq    1.9227634     225636.83
# Prob    7.4803131     800390.84
# Time    0.3757695     209893.62

# Takeaways
# Po1 and Po2 have the highest %IncMSE value, this means our model accuracy will decrease by the value under the
# %IncMSE column if we remove the attribute, in other words our MSE will rise by that amount. The smaller the MSE, the better
# Changing the 'mtry' parameter, still results in more or less the same 'importance'
# I was expecting the Mean of squared residuals to decrease as the parameter 'ntree' is increased
# This is because the more the number of trees the bigger the chances to overfit, hence lowering the variance

########### 10.2
# Logistic Regression can be used to determine the probability of a patient developing a reaction to a medicine
# Predictor's can be 
      # medicine strength
      # dosage
      # age of patient 



########### 10.3

rm(list = ls())
# Read file into a dataframe
germancredit <- read.table("C:\\Users\\Azhar Saiyed\\Desktop\\Analytics\\Micro Masters\\ISYE6501 - Introduction to Analytics Modeling\\Homework\\hw7-Fall_21\\data 10.3\\germancredit.txt", sep=" ")

# Confirm the data read
head(germancredit)

#   V1 V2  V3  V4   V5  V6  V7 V8  V9  V10 V11  V12 V13  V14  V15 V16  V17 V18  V19  V20   V21
# 1 A11  6 A34 A43 1169 A65 A75  4 A93 A101   4 A121  67 A143 A152   2 A173   1 A192 A201   1
# 2 A12 48 A32 A43 5951 A61 A73  2 A92 A101   2 A121  22 A143 A152   1 A173   1 A191 A201   2
# 3 A14 12 A34 A46 2096 A61 A74  2 A93 A101   3 A121  49 A143 A152   1 A172   2 A191 A201   1
# 4 A11 42 A32 A42 7882 A61 A74  2 A93 A103   4 A122  45 A143 A153   1 A173   2 A191 A201   1
# 5 A11 24 A33 A40 4870 A61 A73  3 A93 A101   4 A124  53 A143 A153   2 A173   2 A191 A201   2
# 6 A14 36 A32 A46 9055 A65 A73  2 A93 A101   4 A124  35 A143 A153   1 A172   2 A192 A201   1


# Since we need to execute logistical regression we need to convert our response to binary values first
# Currently the last column (response column) has the values of 1 and 2, we will convert them into 0 and 1 respectively

germancredit$V21[germancredit$V21==1] <- 0
germancredit$V21[germancredit$V21==2] <- 1

head(germancredit)

#   V1 V2  V3  V4   V5  V6  V7 V8  V9  V10 V11  V12 V13  V14  V15 V16  V17 V18  V19  V20   V21
# 1 A11  6 A34 A43 1169 A65 A75  4 A93 A101   4 A121  67 A143 A152   2 A173   1 A192 A201   0
# 2 A12 48 A32 A43 5951 A61 A73  2 A92 A101   2 A121  22 A143 A152   1 A173   1 A191 A201   1
# 3 A14 12 A34 A46 2096 A61 A74  2 A93 A101   3 A121  49 A143 A152   1 A172   2 A191 A201   0
# 4 A11 42 A32 A42 7882 A61 A74  2 A93 A103   4 A122  45 A143 A153   1 A173   2 A191 A201   0
# 5 A11 24 A33 A40 4870 A61 A73  3 A93 A101   4 A124  53 A143 A153   2 A173   2 A191 A201   1
# 6 A14 36 A32 A46 9055 A65 A73  2 A93 A101   4 A124  35 A143 A153   1 A172   2 A192 A201   0

# From the dataset documentation, 1 = Good,  2 = Bad
# So 0 now signifies Good Credit Risk and 1 Bad Credit Risk 


# Split the data into training and test datasets
germancredit_train <- germancredit[1:700,]
germancredit_test <- germancredit[701:1000,]


# Create the logistical regression model using the training dataset
model <- glm(V21~., family=binomial(link="logit"), data = germancredit_train)

summary(model)

# Deviance Residuals: 
#   Min       1Q   Median       3Q      Max  
# -2.7431  -0.6865  -0.3547   0.6603   2.7024  
# 
# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)    
# (Intercept)  8.094e-01  1.318e+00   0.614 0.539040    
# V1A12       -1.634e-01  2.627e-01  -0.622 0.533900    
# V1A13       -1.039e+00  4.368e-01  -2.379 0.017345 *  
#   V1A14       -1.742e+00  2.908e-01  -5.990 2.09e-09 ***
#   V2           2.888e-02  1.109e-02   2.605 0.009177 ** 
#   V3A31        6.540e-01  6.927e-01   0.944 0.345051    
# V3A32       -6.821e-01  5.092e-01  -1.339 0.180424    
# V3A33       -9.090e-01  5.558e-01  -1.635 0.101968    
# V3A34       -1.528e+00  5.305e-01  -2.880 0.003981 ** 
#   V4A41       -1.873e+00  4.937e-01  -3.793 0.000149 ***
#   V4A410      -1.556e+00  8.474e-01  -1.836 0.066314 .  
# V4A42       -8.275e-01  3.200e-01  -2.586 0.009715 ** 
#   V4A43       -8.720e-01  3.037e-01  -2.872 0.004085 ** 
#   V4A44       -1.269e-01  9.259e-01  -0.137 0.890996    
# V4A45       -5.639e-01  6.640e-01  -0.849 0.395753    
# V4A46        4.279e-02  4.545e-01   0.094 0.924983    
# V4A48       -2.364e+00  1.318e+00  -1.794 0.072847 .  
# V4A49       -7.918e-01  4.184e-01  -1.892 0.058447 .  
# V5           1.153e-04  5.572e-05   2.069 0.038552 *  
#   V6A62       -2.399e-01  3.460e-01  -0.693 0.488086    
# V6A63       -4.461e-01  5.256e-01  -0.849 0.396045    
# V6A64       -1.641e+00  6.364e-01  -2.579 0.009922 ** 
#   V6A65       -8.197e-01  3.163e-01  -2.592 0.009548 ** 
#   V7A72       -2.960e-01  5.418e-01  -0.546 0.584866    
# V7A73       -4.289e-01  5.131e-01  -0.836 0.403237    
# V7A74       -1.198e+00  5.565e-01  -2.153 0.031289 *  
#   V7A75       -5.071e-01  5.145e-01  -0.986 0.324340    
# V8           3.565e-01  1.079e-01   3.304 0.000954 ***
#   V9A92       -4.955e-01  4.594e-01  -1.079 0.280776    
# V9A93       -1.299e+00  4.492e-01  -2.891 0.003843 ** 
#   V9A94       -3.874e-01  5.379e-01  -0.720 0.471446    
# V10A102      7.803e-01  4.842e-01   1.612 0.107066    
# V10A103     -1.099e+00  5.261e-01  -2.090 0.036646 *  
#   V11          1.389e-02  1.048e-01   0.133 0.894503    
# V12A122      4.053e-01  3.135e-01   1.293 0.196068    
# V12A123      1.573e-01  2.837e-01   0.555 0.579128    
# V12A124      8.694e-01  5.126e-01   1.696 0.089905 .  
# V13         -1.376e-02  1.140e-02  -1.208 0.227097    
# V14A142      6.347e-02  5.019e-01   0.126 0.899384    
# V14A143     -6.359e-01  2.917e-01  -2.180 0.029250 *  
#   V15A152     -2.121e-01  2.939e-01  -0.722 0.470525    
# V15A153     -9.052e-01  5.847e-01  -1.548 0.121597    
# V16          3.427e-01  2.253e-01   1.521 0.128271    
# V17A172     -7.079e-02  8.640e-01  -0.082 0.934695    
# V17A173      1.246e-02  8.326e-01   0.015 0.988064    
# V17A174      1.442e-01  8.212e-01   0.176 0.860619    
# V18          4.924e-01  3.096e-01   1.591 0.111703    
# V19A192     -3.059e-01  2.500e-01  -1.223 0.221152    
# V20A202     -1.418e+00  8.186e-01  -1.732 0.083288 .  
# ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 850.06  on 699  degrees of freedom
# Residual deviance: 612.64  on 651  degrees of freedom
# AIC: 710.64
# 
# Number of Fisher Scoring iterations: 5


# Record the predictions using the test dataset
pred <- predict(model, germancredit_test, type = "response")
head(pred)

# 701       702       703       704       705       706 
# 0.1225368 0.2279863 0.1827115 0.5964353 0.7393047 0.1289587 

# Round the values
predr <- round(pred ,0)
head(predr)

# 1 2 3 4 5 6 
# 0 1 0 0 1 0 


# Calculate Accuracy - quality of fit
sum(predr == germancredit_test[,21])/300
# 0.7533


# Given that the cost of incorrectly identifying a bad customer as good is a lot, we convert the raw (unrounded)
# predicted values such that only values less than, say 0.3, are rounded to be 0, vs the default 0.5.

predr[pred < 0.3] <- 0
predr[pred >= 0.3] <- 1
sum(predr == germancredit_test[,21])/300
# 0.7333

#The model's accuracy goes down slightly but we guard ourselves against false positives 





